# Furioos SDK JS example
This project is a simple nodeJS server that render a single HTML page.
It is a first step to try Furioos SDK with your links on Furioos.
It also a way to debug localy your application.

# Requirements
[Node.JS](http://nodejs.org/) -- v12.x or newer

# Installation
```bash
npm install
```
or
```bash
yarn
```

# Run

```bash
npm run start
```
or
```bash
yarn start
```

A nodeJS server running on port 8080
